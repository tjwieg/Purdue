/**
  ******************************************************************************
  * @file    main.c 
  * @author  Zhou Zeng
  * @version V1.1.0
  * @date    10-Oct-2018
  * @brief   Main program body.
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "ME586.h"

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


int main(void)
{
	int value = 2048;
	initcom();
	initadc();
	initdac();
	
	printf("DAC:\t Valve:\t Engine: \n\r");
	
	while(1){
		WaitForKeypress();
		d_to_a(0,value);
		shownum(value);
		putchar('\t');
		
		WaitForKeypress();
		shownum(a_to_d(1));
		putchar('\t');
		
		WaitForKeypress();
		shownum(a_to_d(2));
		printf("\n\r");
		
		value=value+64;
		if(value>2496){
			break;
		}	
	}
	
} //end of main program


void timehand(void){
}

void inthand(void){
}

/***********************END OF FILE****/
