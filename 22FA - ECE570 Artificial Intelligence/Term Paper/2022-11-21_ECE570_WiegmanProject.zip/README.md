# How to run the experiment

1. Download [VALID-Depth and VALID-Seg](https://sites.google.com/view/valid-dataset/) and place them both in a subfolder called "VALID2020".
2. Download the ShapeConv library (my fork is available [here](https://github.itap.purdue.edu/wiegman/ShapeConv)) and place it in a subfolder called "ShapeConv".
3. Run `WiegmanProjectCode.ipynb` in a Jupyter notebook.

The output from my own run is saved in `WiegmanProjectCode.html`.

----

# Authorship

- Everything in `WiegmanProjectCode.ipynb` is my own original work.
- The ShapeConv library was originally published by Hanchao Leng on GitHub, available [here](https://github.com/hanchaoleng/shapeconv).
    - My modified fork just added a `ShapeConv` prefix to each import statement so it could be called from a subfolder. The changelog with diff is available [here](https://github.itap.purdue.edu/wiegman/ShapeConv/commit/ff7e36184f7acd2b32ccf34ceaf5e81ede1444e6).
- The general model architecture for my neural network was inspired by that of [DepthAwareCNN](https://github.com/laughtervv/DepthAwareCNN), which was originally based on DeepLab v1.
    - I referenced [this Pytorch implementation](https://github.com/wangleihitcs/DeepLab-V1-PyTorch/blob/master/nets/vgg.py) for insight on the original DeepLab structure.
- The VALID dataset was published by Chen et al. in 2020 and is available for download [here](https://sites.google.com/view/valid-dataset/).
    - This is a set of simulated aerial RGB-D imagery, with annotations for segmentation and object detection.

Everything for this project is available on Purdue University GitHub [here](https://github.itap.purdue.edu/wiegman/ECE570).
